package DIO_APIREST_WITH_SPRINGBOOT.lab1_java_bootcamp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab1JavaBootcampApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab1JavaBootcampApplication.class, args);
	}

}
