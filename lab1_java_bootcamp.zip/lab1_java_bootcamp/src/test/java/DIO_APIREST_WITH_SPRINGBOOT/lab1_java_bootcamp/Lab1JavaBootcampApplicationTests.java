package DIO_APIREST_WITH_SPRINGBOOT.lab1_java_bootcamp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1JavaBootcampApplicationTests {

	@Test
	void contextLoads() {
	}

}
